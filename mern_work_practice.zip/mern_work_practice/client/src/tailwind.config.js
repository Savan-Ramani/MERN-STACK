module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}', // Path to your React components
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
