import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; // Global styles, including Tailwind
import App from './App';
import { Provider } from 'react-redux';
import store from './redux/store'; // Import store from the correct path

// Render the React app and wrap it with Redux Provider to provide the store
ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
);
