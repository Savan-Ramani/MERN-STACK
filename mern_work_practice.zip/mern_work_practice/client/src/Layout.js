import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../src/styles/Layout.css'; // Import the custom CSS for the layout
import Dashboard from './components/Dashboard';

const Layout = ({ children }) => {
  const location = useLocation(); // To highlight the active link

  return (
    <div className="layout-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <Link 
                to="/register" 
                className={location.pathname === "/register" ? "active" : ""}
              >
                Register
              </Link>
            </li>
           
            <li>
              <Link 
                to="/login" 
                className={location.pathname === "/login" ? "active" : ""}
              >
                Login
              </Link>
            </li>
          </ul>
        </nav>
      </aside>
   
      <main className="main-content">
        <div className="main-content-header">
          {/* You can add a title or breadcrumbs for better user navigation */}
          {/* {children} */}
          <Dashboard />
        </div>
      </main>
    </div>
  );
};

export default Layout;
