import { createSlice } from '@reduxjs/toolkit';

// Define the initial state for the user
const initialState = {
  isAuthenticated: false,
  userData: {},
};

// Create a slice for the user
const userSlice = createSlice({
  name: 'user',  // Slice name
  initialState,
  reducers: {
    login: (state, action) => {
      state.isAuthenticated = true;
      state.userData = action.payload;
    },
    logout: (state) => {
      state.isAuthenticated = false;
      state.userData = {};
    },
    setUserData: (state, action) => {
      state.userData = action.payload;
    },
  },
});

// Export the actions
export const { login, logout, setUserData } = userSlice.actions;

// Export the reducer
export default userSlice.reducer;
