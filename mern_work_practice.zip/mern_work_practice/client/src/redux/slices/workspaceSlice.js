// workspaceSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

export const fetchWorkspaces = createAsyncThunk('workspace/fetchWorkspaces', async () => {
  const response = await api.get('/workspaces');
  return response.data;
});

const workspaceSlice = createSlice({
  name: 'workspace',
  initialState: {
    workspaces: [],
    loading: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchWorkspaces.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchWorkspaces.fulfilled, (state, action) => {
        state.workspaces = action.payload;
        state.loading = false;
      })
      .addCase(fetchWorkspaces.rejected, (state) => {
        state.loading = false;
      });
  },
});

export default workspaceSlice.reducer;
