import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice'; // Correct path to your userSlice
import workspaceReducer from './slices/workspaceSlice'; // Correct path to your workspaceSlice

// Create the Redux store with reducers
const store = configureStore({
  reducer: {
    user: userReducer,
    workspace: workspaceReducer,
  },
});

export default store;
