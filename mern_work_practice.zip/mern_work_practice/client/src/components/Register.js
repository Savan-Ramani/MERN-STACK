import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { CContainer, CRow, CCol, CForm, CFormLabel, CFormInput, CButton, CFormText, CFormSelect } from '@coreui/react';

// Import the custom CSS for the Register component
import '../styles/Register.css';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [company, setCompany] = useState('');
  const [dob, setDob] = useState('');
  const [department, setDepartment] = useState('');
  const [mobile, setMobile] = useState('');
  const [profilePicture, setProfilePicture] = useState(null);
  const [role, setRole] = useState(null);
  const [joiningDate, setJoiningDate] = useState('');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Validation function
  const validate = () => {
    const errors = {};

    if (!name) errors.name = "Full name is required.";
    if (!email) {
      errors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = "Email is invalid.";
    }
    if (!password) errors.password = "Password is required.";
    else if (password.length < 6) errors.password = "Password must be at least 6 characters long.";
    if (!company) errors.company = "Company name is required.";
    if (!dob) errors.dob = "Date of Birth is required.";
    if (!role) errors.role = "Role is required.";
    if (!department) errors.department = "Department is required.";
    if (!mobile) errors.mobile = "Mobile number is required.";
    else if (!/^\d{10}$/.test(mobile)) errors.mobile = "Mobile number must be 10 digits.";
    if (!joiningDate) errors.joiningDate = "Joining date is required.";

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('company', company);
    formData.append('dob', dob);
    formData.append('role', role);
    formData.append('department', department);
    formData.append('mobile', mobile);
    formData.append('joiningDate', joiningDate);
    if (profilePicture) {
      formData.append('profilePicture', profilePicture);
    }

    // Debug: Log FormData contents
    for (let [key, value] of formData.entries()) {
      console.log(key + ": " + value);
    }

    try {
      await api.post('/auth/register', formData, {
        // headers: {
        //   'Content-Type': 'multipart/form-data', // Allow file upload
        // },
      });
      console.log("role : " + role);
      if (role == "superadmin") {
        navigate('/super-admin/dashboard'); // Redirect after successful registration
      }else if(role == "workspaceadmin"){
        console.log("profile route");
        navigate('/admin-dashboard');
      }else{
        navigate('/employee-profile');
      }
      
    } catch (error) {
      console.error('Error registering:', error.response?.data || error);
    }
  };

  return (
    <CContainer className="register-container py-5">
      <CRow className="justify-content-center">
        <CCol xs="12" md="8" lg="6">
          <div className="text-center mb-4">
            <h2 className="register-title">Register Employee</h2>
            <p className="register-subtitle">Fill in the details below to register</p>
          </div>
          <CForm onSubmit={handleSubmit}>
            {/* Full Name and Email */}
            <CRow className="mb-4">
              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="name" className="form-label">Full Name</CFormLabel>
                <CFormInput
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter full name"
                  required
                  className="form-input"
                />
                {errors.name && <CFormText color="danger">{errors.name}</CFormText>}
              </CCol>

              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="email" className="form-label">Email Address</CFormLabel>
                <CFormInput
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email"
                  required
                  className="form-input"
                />
                {errors.email && <CFormText color="danger">{errors.email}</CFormText>}
                </CCol>
              </CRow>

            {/* Password and Company */}
            <CRow className="mb-4">
              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="password" className="form-label">Password</CFormLabel>
                <CFormInput
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  required
                  className="form-input"
                />
                {errors.password && <CFormText color="danger">{errors.password}</CFormText>}
              </CCol>

              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="company" className="form-label">Company</CFormLabel>
                <CFormInput
                  type="text"
                  id="company"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Enter company name"
                  className="form-input"
                />
                {errors.company && <CFormText color="danger">{errors.company}</CFormText>}
              </CCol>
            </CRow>

            {/* Date of Birth and Department */}
            <CRow className="mb-4">
              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="dob" className="form-label">Date of Birth</CFormLabel>
                <CFormInput
                  type="date"
                  id="dob"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="form-input"
                />
                {errors.dob && <CFormText color="danger">{errors.dob}</CFormText>}
              </CCol>

              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="department" className="form-label">Department</CFormLabel>
                <CFormInput
                  type="text"
                  id="department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="Enter department"
                  className="form-input"
                />
                {errors.department && <CFormText color="danger">{errors.department}</CFormText>}
              </CCol>
            </CRow>

            {/* Mobile and Joining Date */}
            <CRow className="mb-4">
              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="mobile" className="form-label">Mobile</CFormLabel>
                <CFormInput
                  type="tel"
                  id="mobile"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="Enter mobile number"
                  className="form-input"
                />
                {errors.mobile && <CFormText color="danger">{errors.mobile}</CFormText>}
              </CCol>

              <CCol xs="12" sm="6">
                <CFormLabel htmlFor="joiningDate" className="form-label">Joining Date</CFormLabel>
                <CFormInput
                  type="date"
                  id="joiningDate"
                  value={joiningDate}
                  onChange={(e) => setJoiningDate(e.target.value)}
                  className="form-input"
                />
                {errors.joiningDate && <CFormText color="danger">{errors.joiningDate}</CFormText>}
              </CCol>
            </CRow>

            {/* Profile Picture Upload */}
            <CRow className="mb-4">
              <CCol xs="12">
                <CFormLabel htmlFor="profilePicture" className="form-label">Profile Picture</CFormLabel>
                <CFormInput
                  type="file"
                  id="profilePicture"
                  onChange={(e) => setProfilePicture(e.target.files[0])}
                  className="form-input"
                />
                <CFormText color="muted">Optional: Upload a profile picture</CFormText>
              </CCol>
            </CRow>

            {/* Role Selection */}
          <CRow className="mb-4">
            <CCol xs="12">
              <CFormLabel htmlFor="role" className="form-label">Role</CFormLabel>
              <CFormSelect
                id="role"
                value={role}  // Assuming you have a state for role
                onChange={(e) => setRole(e.target.value)} // Assuming you have a setter for the role
                className="form-input"
                required
              >
                <option value="">Select Role</option>
                <option value="superadmin">Super Admin</option>
                <option value="workspaceadmin">Workspace Admin</option>
                <option value="employee">Employee</option>
              </CFormSelect>
            </CCol>
          </CRow>

            {/* Submit Button */}
            <CRow>
              <CCol xs="12">
                <CButton color="primary" type="submit" block className="submit-button">
                  Register
                </CButton>
              </CCol>
            </CRow>
          </CForm>

          {/* Login Prompt */}
          <CRow className="mt-3">
            <CCol xs="12" className="text-center">
              <p className="login-prompt">
                Already have an account? <a href="/login" className="login-link">Login here</a>
              </p>
            </CCol>
          </CRow>
        </CCol>
      </CRow>
    </CContainer>
  );
};

export default Register;
