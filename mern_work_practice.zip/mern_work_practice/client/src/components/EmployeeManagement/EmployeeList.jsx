import React, { useState, useEffect } from 'react';
import api from '../../utils/api';  // Ensure this is set up properly
import ReactPaginate from 'react-paginate'
import { Link } from 'react-router-dom'; 

const EmployeeList = () => {
    const [employees, setEmployees] = useState([]);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(0);
    const [totalEmployees, setTotalEmployees] = useState(0);  // Total employees for pagination
    const [employeesPerPage, setEmployeesPerPage] = useState(10);  // Number of employees per page


    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                // Fetch data from the API
                const response = await api.get(`/employee?page=${currentPage + 1}&limit=${employeesPerPage}`);

                // Log the full response for debugging
                console.log("API Response:", response);

                // Try different ways to extract employees from response
                let employeeData = [];

                // If 'employees' is an array, use it directly
                if (Array.isArray(response.data.employees)) {
                    employeeData = response.data.employees;
                } else if (Array.isArray(response.data)) {
                    // If response.data is already an array
                    employeeData = response.data;
                } else {
                    // If the data is wrapped in another object, try accessing it
                    console.log("Fallback: Processing alternative response structure");

                    // Here you can add more logic if your API returns data in a different structure
                    // Example:
                    // if (response.data.result && Array.isArray(response.data.result)) {
                    //   employeeData = response.data.result;
                    // }

                    // For demonstration, let's just check the response
                    if (response.data && response.data[0] && response.data[0].employees) {
                        employeeData = response.data[0].employees;  // Example structure with nested data
                    } else {
                        console.error('Unexpected data format:', response.data);
                    }
                }

                // Finally, update state with the employee data
                if (employeeData.length > 0) {
                    setEmployees(employeeData);
                } else {
                    setError('No employees found or unexpected data format.');
                }
            } catch (error) {
                console.error('Error fetching employees:', error);
                setError('An error occurred while fetching employees.');
            }
        };

        fetchEmployees();  // Call the function when the component mounts
    }, []);  // Empty array ensures this runs once on mount

    const handlePageClick = (data) => {
        setCurrentPage(data.selected);
    };

    const handleEdit = (id) => {
        // Navigate to edit page or open a modal

        console.log(`Edit employee with ID: ${id}`);
    };

    const handleDelete = async (id) => {
        try {
            const response = await api.delete(`/employee/${id}`);
            if (response.status === 200) {
                // On successful delete, re-fetch employee data
                alert('Employee deleted successfully');
                setEmployees(employees.filter(employee => employee._id !== id));
            }
        } catch (error) {
            console.error('Error deleting employee:', error);
            alert('Failed to delete employee');
        }
    };

    const handleAdd = () => {
        // Navigate to the "Add Employee" page or show a modal
        console.log("Add new employee");
    };


    return (
        <><div>
            <h1>Employee List</h1>

            {error && <p>{error}</p>}
            <button onClick={handleAdd}>Add Employee</button>

            {employees.length === 0 ? (
                <p>No employees found.</p>
            ) : (
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employees.map((employee) => (
                            <tr key={employee._id || employee.id}>
                                <td>{employee.name}</td>
                                <td>{employee.email}</td>
                                <td>{employee.phone}</td>
                                <td>{employee.address}</td>
                                <td>
                                    <Link to="/edit-employee">
                                        <button>Edit Employee</button>
                                    </Link>
                                    <button onClick={() => handleDelete(employee._id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            <div>
                {/* Pagination */}
                <ReactPaginate
                    previousLabel={"Previous"}
                    nextLabel={"Next"}
                    breakLabel={"..."}
                    pageCount={Math.ceil(totalEmployees / employeesPerPage)} // Calculate number of pages
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    activeClassName={"active"} />
            </div>
        </div></>
    );
};

export default EmployeeList;
