import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../utils/api';

const EditEmployee = () => {
  const { id } = useParams();  // Extract the employee ID from the URL
  const navigate = useNavigate();
  const [employee, setEmployee] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  // Fetch the employee data based on the ID from the URL
  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const response = await api.get(`/employee/${id}`);
        setEmployee(response.data);  // Populate the employee data in the form
      } catch (error) {
        console.error('Error fetching employee data:', error);
        alert('Error fetching employee data');
      }
    };

    fetchEmployee();
  }, [id]);  // Re-fetch data if the ID changes

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee({ ...employee, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.put(`/employee/${id}`, employee); // Send PUT request to update
      if (response.status === 200) {
        alert('Employee updated successfully');
        navigate('/employees');  // Navigate back to employee list
      }
    } catch (error) {
      console.error('Error updating employee:', error);
      alert('Error updating employee');
    }
  };

  return (
    <div>
      <h1>Edit Employee</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={employee.name}
            onChange={handleChange}
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            name="email"
            value={employee.email}
            onChange={handleChange}
          />
        </label>
        <label>
          Phone:
          <input
            type="tel"
            name="phone"
            value={employee.phone}
            onChange={handleChange}
          />
        </label>
        <label>
          Address:
          <input
            type="text"
            name="address"
            value={employee.address}
            onChange={handleChange}
          />
        </label>
        <button type="submit">Update Employee</button>
      </form>
    </div>
  );
};

export default EditEmployee;
