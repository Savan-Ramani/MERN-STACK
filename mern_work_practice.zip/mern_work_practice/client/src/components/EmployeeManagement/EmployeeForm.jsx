import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';  // Import useNavigate from react-router-dom
import api from '../../utils/api';

const EmployeeForm = () => {
  const [employee, setEmployee] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    companyName: '',
    companyAddress: '',
    experience: 0,
    department: '',
    status: 'active', // Default to active
  });

  const navigate = useNavigate();  // Replace useHistory with useNavigate

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEmployee({
      ...employee,
      [name]: value,
    });
  };

  // Handle form submission (add employee)
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token'); // Assuming token is in localStorage for auth

      // POST request to add new employee
      await api.post('/employee', employee, {
        headers: { Authorization: `Bearer ${token}` },
      });

      alert('Employee added successfully!');
      setEmployee({
        name: '',
        email: '',
        phone: '',
        address: '',
        companyName: '',
        companyAddress: '',
        experience: 0,
        department: '',
        status: 'active',
      }); // Clear the form after submission

      // Navigate to the employee list or dashboard (you can customize this route)
      navigate('/employees'); // Using useNavigate instead of useHistory
    } catch (error) {
      console.error('Error adding employee:', error);
      alert('An error occurred while adding the employee.');
    }
  };

  return (
    <div className="employee-form">
      <h2>Add New Employee</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name</label>
          <input
            type="text"
            name="name"
            value={employee.name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={employee.email}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Phone</label>
          <input
            type="text"
            name="phone"
            value={employee.phone}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={employee.address}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Company Name</label>
          <input
            type="text"
            name="companyName"
            value={employee.companyName}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Company Address</label>
          <input
            type="text"
            name="companyAddress"
            value={employee.companyAddress}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Experience (in years)</label>
          <input
            type="number"
            name="experience"
            value={employee.experience}
            onChange={handleInputChange}
            min="0"
            required
          />
        </div>
        <div>
          <label>Department</label>
          <input
            type="text"
            name="department"
            value={employee.department}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Status</label>
          <select
            name="status"
            value={employee.status}
            onChange={handleInputChange}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <button type="submit">Add Employee</button>
      </form>
    </div>
  );
};

export default EmployeeForm;
