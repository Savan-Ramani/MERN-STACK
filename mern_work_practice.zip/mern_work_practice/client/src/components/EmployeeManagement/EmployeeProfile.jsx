import React from 'react';

const EmployeeProfile = ({ profile }) => {
  if (!profile) {
    return <p>Loading...</p>; // Show a loading message while the profile is being fetched
  }

  return (
    <div>
      <h1>Employee Profile</h1>
      <div>
        <h3>Name: {profile.name}</h3>
        <p><strong>Email:</strong> {profile.email}</p>
        <p><strong>Phone:</strong> {profile.phone}</p>
        <p><strong>Address:</strong> {profile.address}</p>
        <p><strong>Company Name:</strong> {profile.companyName}</p>
        <p><strong>Company Address:</strong> {profile.companyAddress}</p>
        <p><strong>Experience:</strong> {profile.experience}</p>
      </div>
    </div>
  );
};

export default EmployeeProfile;
