import React, { useState, useEffect } from 'react';
import { CCard, CCardBody, CCardHeader, CForm, CFormInput, CButton } from '@coreui/react';
import api from '../utils/api';

const Profile = () => {
  const [user, setUser] = useState({});
  
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await api.get('/profile');
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    };

    fetchProfile();
  }, []);

  const handleSave = () => {
    // Send profile updates to backend
  };

  return (
    <div>
      <h2>Profile Page</h2>
      <CCard>
        <CCardHeader>My Profile</CCardHeader>
        <CCardBody>
          <CForm>
            <CFormInput value={user.name} label="Full Name" />
            <CFormInput value={user.email} label="Email" />
            <CFormInput value={user.phone} label="Phone Number" />
            <CButton color="primary" onClick={handleSave}>Save</CButton>
          </CForm>
        </CCardBody>
      </CCard>
    </div>
  );
};

export default Profile;
