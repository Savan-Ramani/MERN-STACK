import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api'; // Assuming this is where you have your API utility
import {
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CForm,
  CFormInput,
  CFormLabel,
  CFormTextarea,
  CFormText
} from '@coreui/react';

// Custom styles
import '../styles/Register.css';

const SuperAdminDashboard = () => {
  const [workspaces, setWorkspaces] = useState([]); // State to hold the list of workspaces
  const [showModal, setShowModal] = useState(false); // State to control the modal visibility
  const [currentWorkspace, setCurrentWorkspace] = useState(null); // For editing specific workspace
  const [workspaceDetails, setWorkspaceDetails] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    address: '',
    logo: null,
  });
  const [errors, setErrors] = useState({}); // Form validation errors
  const [message, setMessage] = useState(null); // To hold success or error messages

  const navigate = useNavigate();

  // Fetch workspaces from the API
  const fetchWorkspaces = async () => {
    try {
      const response = await api.get('/workspaces'); // Make the API call to fetch workspaces
      setWorkspaces(response.data); // Update state with the fetched data
    } catch (error) {
      console.error('Error fetching workspaces:', error.response?.data || error);
      setMessage({ type: 'error', text: 'Error fetching workspaces' });
    }
  };

  // Call the fetchWorkspaces function when the component is mounted
  useEffect(() => {
    fetchWorkspaces(); // Fetch workspaces on component load
  }, []);

  // Handle creating or editing a workspace
  const handleEditWorkspace = (workspace) => {
    setWorkspaceDetails(workspace);
    setCurrentWorkspace(workspace._id);
    setShowModal(true); // Show the modal for editing the workspace
  };

  // Handle deleting a workspace
  const handleDeleteWorkspace = async (workspaceId) => {
    try {
      await api.delete(`/workspaces/${workspaceId}`); // Make the API call to delete the workspace
      setWorkspaces(workspaces.filter(workspace => workspace._id !== workspaceId)); // Update state after deletion
      setMessage({ type: 'success', text: 'Workspace deleted successfully!' });
    } catch (error) {
      console.error('Error deleting workspace:', error.response?.data || error);
      setMessage({ type: 'error', text: 'Error deleting workspace' });
    }
  };

  // Handle saving a workspace (both create and edit)
  const handleSaveWorkspace = async () => {
    const validationErrors = {};

    // Simple validation
    if (!workspaceDetails.name) validationErrors.name = 'Workspace name is required.';
    if (!workspaceDetails.email) validationErrors.email = 'Email is required.';
    if (!workspaceDetails.phone) validationErrors.phone = 'Phone number is required.';
    if (!workspaceDetails.password) validationErrors.password = 'Password is required.';
    if (!workspaceDetails.address) validationErrors.address = 'Address is required.';

    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) return;

    try {
      if (currentWorkspace) {
        // Edit existing workspace
        await api.put(`/workspaces/${currentWorkspace}`, workspaceDetails); // PUT request to update workspace
        setMessage({ type: 'success', text: 'Workspace updated successfully!' });
      } else {
        // Create a new workspace
        const response = await api.post('/workspaces', workspaceDetails); // POST request to create workspace

        // If duplicate entry
        console.log("response : " + JSON.stringify(response));

        if
          (response.data.status == 409) {
          setMessage({ type: 'error', text: 'Workspace with the same name, email, or phone already exists.' });

        } else {
          setMessage({ type: 'success', text: 'Workspace created successfully!' });
        }


      }

      // Fetch the updated list of workspaces after save
      fetchWorkspaces();

      setShowModal(false); // Close the modal after saving
    } catch (error) {
      console.error('Error saving workspace:', error.response?.data || error);
      setMessage({ type: 'error', text: 'Error saving workspace' });
    }
  };

  return (
    <div className="super-admin-dashboard">
      <h2 className="register-title text-center">Super Admin Dashboard</h2>
      <p className="register-subtitle text-center">Manage your workspaces</p>

      {/* Show success or error message */}
      {message && (
        <div
          className={`alert alert-${message.type === 'error' ? 'danger' : 'success'}`}
          role="alert"
          style={{ color: message.type === 'error' ? 'red' : 'green' }} // Red for errors, green for success
        >
          {message.text}
        </div>
      )}

      {/* Create Workspace Button */}
      <CButton
        color="primary"
        onClick={() => {
          setWorkspaceDetails({ name: '', email: '', phone: '', password: '', address: '', logo: null }); // Reset form for new workspace
          setCurrentWorkspace(null); // Clear current workspace ID for creating a new one
          setShowModal(true);  // Open the modal
        }}
        className="submit-button mb-3"
      >
        Create Workspace
      </CButton>

      {/* Workspaces Grid */}
      <div className="workspaces-grid">
        {workspaces.map((workspace) => (
          <div key={workspace._id} className="workspace-card">
            <div className="workspace-card-header">
              <img src={workspace.logo} alt="Workspace Logo" width="50" />
              <h5>{workspace.name}</h5>
            </div>
            <div className="workspace-card-body">
              <p style={{ fontSize: '16px' }}><strong>Email:</strong> {workspace.email}</p>
              <p style={{ fontSize: '16px' }}><strong>Phone:</strong> {workspace.phone}</p>
              <p style={{ fontSize: '16px' }}><strong>Address:</strong> {workspace.address}</p>
            </div>
            <div className="workspace-card-footer">
              <CButton
                color="warning"
                onClick={() => handleEditWorkspace(workspace)}
                className="action-button edit-button"
              >
                Edit
              </CButton>
              <CButton
                color="danger"
                onClick={() => {
                  const isConfirmed = window.confirm("Are you sure you want to delete this workspace?");
                  if (isConfirmed) {
                    handleDeleteWorkspace(workspace._id); // Proceed with the deletion if the user confirms
                  }
                }}
                className="action-button delete-button"
              >
                Delete
              </CButton>
            </div>
          </div>
        ))}
      </div>

      {/* Modal for Creating/Editing Workspace */}
      <CModal
        visible={showModal}
        onClose={() => setShowModal(false)}
        key={showModal} // This forces a re-render when the visibility changes
        className="register-modal"
      >
        <CModalHeader closeButton>
          <CModalTitle className="register-title">{currentWorkspace ? 'Edit Workspace' : 'Create Workspace'}</CModalTitle>
        </CModalHeader>

        <CModalBody className="register-container">
          <CForm>
            <CFormLabel htmlFor="name" className="form-label">Workspace Name</CFormLabel>
            <CFormInput
              type="text"
              id="name"
              value={workspaceDetails.name}
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, name: e.target.value })}
              required
              className="form-input"
            />
            {errors.name && <CFormText color="danger">{errors.name}</CFormText>}

            <CFormLabel htmlFor="email" className="form-label">Email</CFormLabel>
            <CFormInput
              type="email"
              id="email"
              value={workspaceDetails.email}
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, email: e.target.value })}
              required
              className="form-input"
            />
            {errors.email && <CFormText color="danger">{errors.email}</CFormText>}

            <CFormLabel htmlFor="phone" className="form-label">Phone</CFormLabel>
            <CFormInput
              type="tel"
              id="phone"
              value={workspaceDetails.phone}
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, phone: e.target.value })}
              required
              className="form-input"
            />
            {errors.phone && <CFormText color="danger">{errors.phone}</CFormText>}

            <CFormLabel htmlFor="password" className="form-label">Password</CFormLabel>
            <CFormInput
              type="password"
              id="password"
              value={workspaceDetails.password}
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, password: e.target.value })}
              required
              className="form-input"
            />
            {errors.password && <CFormText color="danger">{errors.password}</CFormText>}

            <CFormLabel htmlFor="address" className="form-label">Address</CFormLabel>
            <CFormTextarea
              id="address"
              value={workspaceDetails.address}
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, address: e.target.value })}
              required
              className="form-input"
            />
            {errors.address && <CFormText color="danger">{errors.address}</CFormText>}

            <CFormLabel htmlFor="logo" className="form-label">Logo</CFormLabel>
            <CFormInput
              type="file"
              id="logo"
              onChange={(e) => setWorkspaceDetails({ ...workspaceDetails, logo: e.target.files[0] })}
              className="form-input"
            />
          </CForm>
        </CModalBody>

        <CModalFooter>
          <CButton
            color="secondary"
            onClick={() => setShowModal(false)}
            className="submit-button"
          >
            Close
          </CButton>
          <CButton
            color="primary"
            onClick={handleSaveWorkspace}
            className="submit-button"
          >
            Save
          </CButton>
        </CModalFooter>
      </CModal>
    </div>
  );
};

export default SuperAdminDashboard;








// useEffect(() => {
//   // Fetch all workspaces (simulation)
//   setWorkspaces([
//     {
//       id: 1,
//       name: 'Workspace 1',
//       email: 'workspace1@example.com',
//       phone: '123-456-7890',
//       password: 'password1',
//       address: '123 Workspace St.',
//       logo: 'https://via.placeholder.com/50',
//     },
//     {
//       id: 2,
//       name: 'Workspace 2',
//       email: 'workspace2@example.com',
//       phone: '234-567-8901',
//       password: 'password2',
//       address: '456 Workspace Ave.',
//       logo: 'https://via.placeholder.com/50',
//     },
//   ]);
// }, []);