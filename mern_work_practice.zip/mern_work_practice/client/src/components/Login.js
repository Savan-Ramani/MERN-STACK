import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { loginUser } from '../redux/slices/authSlice';
import { useNavigate } from 'react-router-dom';
import { CContainer, CRow, CCol, CForm, CFormLabel, CFormInput, CButton, CFormText } from '@coreui/react';

// Import the custom CSS for the Login component
import '../styles/Login.css';
import api from '../utils/api';  // Assuming you have an API utility to handle requests

const Login = () => {
  const [usernameOrEmail, setUsernameOrEmail] = useState(''); // Used to store either username or email
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});  // Form validation errors
  const [message, setMessage] = useState(null);  // Alert message state
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Validation function
  const validate = () => {
    const errors = {};
    if (!usernameOrEmail) errors.usernameOrEmail = "Email or Username is required.";
    if (!password) errors.password = "Password is required.";

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      // Assuming `api.post` is a function that sends the login request
      const response = await api.post('/auth/login', { email: usernameOrEmail, password });

      // Check response status and handle accordingly
      if (response.status === 200) {
        // Handle successful login
        const user = response.data.user;
        dispatch(loginUser(user));  // Assuming you have a Redux action for storing user details
        if (user.role === "superadmin") {
          navigate('/super-admin/dashboard');
        } else if (user.role === "workspaceadmin") {
          navigate('/admin-dashboard');
        } else {
          navigate('/employee-profile');
        }
      } else if (response.status === 400) {
        // Invalid credentials
        setMessage({ type: 'error', text: 'Invalid credentials. Please try again.' });
      } else if (response.status === 500) {
        // Server error
        setMessage({ type: 'error', text: 'Something went wrong. Please try again later.' });
      }
    } catch (error) {
      console.error('Login failed:', error);
      setMessage({ type: 'error', text: 'An error occurred. Please try again later.' });
    }
  };

  return (
    <CContainer className="login-container py-5">
      <CRow className="justify-content-center">
        <CCol xs="12" md="8" lg="6">
          <div className="text-center mb-4">
            <h2 className="login-title">Login</h2>
            <p className="login-subtitle">Please enter your email or username and password</p>
          </div>
          {/* Display alert message */}
          {message && (
            <div
              className={`alert alert-${message.type === 'error' ? 'danger' : 'success'}`}
              role="alert"
              style={{ color: message.type === 'error' ? 'red' : 'green' }}
            >
              {message.text}
            </div>
          )}

          <CForm onSubmit={handleSubmit}>
            <CRow className="mb-4">
              <CCol xs="12">
                <CFormLabel htmlFor="usernameOrEmail" className="form-label">Username or Email</CFormLabel>
                <CFormInput
                  type="text"
                  id="usernameOrEmail"
                  value={usernameOrEmail}
                  onChange={(e) => setUsernameOrEmail(e.target.value)}
                  placeholder="Enter your username or email"
                  required
                  className="form-input"
                />
              </CCol>
            </CRow>

            <CRow className="mb-4">
              <CCol xs="12">
                <CFormLabel htmlFor="password" className="form-label">Password</CFormLabel>
                <CFormInput
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  required
                  className="form-input"
                />
              </CCol>
            </CRow>

            <CRow className="mb-3">
              <CCol xs="12" className="text-center">
                <CFormText>
                  <small>If you don't have an account, <a href="/register">register here</a>.</small>
                </CFormText>
              </CCol>
            </CRow>

            <CRow>
              <CCol xs="12">
                <CButton color="primary" type="submit" block className="submit-button">
                  Login
                </CButton>
              </CCol>
            </CRow>
          </CForm>
        </CCol>
      </CRow>
    </CContainer>
  );
};

export default Login;
