import React from 'react';
import { Pie, Bar, Line } from 'react-chartjs-2';
import '../styles/Dashboard.css'; // Import the CSS file

const Dashboard = () => {
  const data = {
    labels: ['Employee 1', 'Employee 2', 'Employee 3'],
    datasets: [
      {
        data: [65, 59, 80],
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false, // Allow custom width and height
  };

  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>

      <div className="chart-container">
        <h3 className="chart-title">Pie Chart</h3>
        <Pie data={data} options={options} />
      </div>

      <div className="chart-container">
        <h3 className="chart-title">Bar Chart</h3>
        <Bar data={data} options={options} />
      </div>

      <div className="chart-container">
        <h3 className="chart-title">Line Chart</h3>
        <Line data={data} options={options} />
      </div>
    </div>
  );
};

export default Dashboard;
