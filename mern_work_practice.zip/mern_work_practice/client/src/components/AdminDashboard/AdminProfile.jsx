import React from 'react';

const AdminProfile = ({ profile }) => {
  return (
    <div className="admin-profile">
      <h3>Admin Profile</h3>
      <p><strong>Name:</strong> {profile.name}</p>
      <p><strong>Email:</strong> {profile.email}</p>
    </div>
  );
};

export default AdminProfile;
