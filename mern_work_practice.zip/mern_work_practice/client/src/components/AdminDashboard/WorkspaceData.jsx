import React from 'react';

const WorkspaceData = ({ data }) => {
  return (
    <div className="workspace-data">
      <h3>Workspace Details</h3>
      <p><strong>Name:</strong> {data.name}</p>
      <p><strong>Admin Name:</strong> {data.admin.name}</p>
    </div>
  );
};

export default WorkspaceData;
