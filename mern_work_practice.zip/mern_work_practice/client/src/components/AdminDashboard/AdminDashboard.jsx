import React, { useState, useEffect } from 'react';
import axios from 'axios';
import WorkspaceData from './WorkspaceData';
import AdminProfile from './AdminProfile';
import EmployeeForm from '../EmployeeManagement/EmployeeForm';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const [workspaceData, setWorkspaceData] = useState(null);
  const [adminProfile, setAdminProfile] = useState(null);
  const [isFormVisible, setIsFormVisible] = useState(false);

  // Function to handle showing/hiding the EmployeeForm
  const toggleEmployeeForm = () => {
    setIsFormVisible(!isFormVisible);
  };

  useEffect(() => {
    const fetchWorkspaceData = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/api/admin/workspace', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setWorkspaceData(response.data);
      } catch (error) {
        console.error('Error fetching workspace data:', error);
      }
    };

    const fetchAdminProfile = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/api/admin/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setAdminProfile(response.data);
      } catch (error) {
        console.error('Error fetching admin profile:', error);
      }
    };

    fetchWorkspaceData();
    fetchAdminProfile();
  }, []);

  return (
    <div className="admin-dashboard">
      <h2>Workspace Admin Dashboard</h2>
           {/* Button to toggle visibility of the EmployeeForm */}
           <button className="btn btn-primary" onClick={toggleEmployeeForm}>
        {isFormVisible ? 'Close Employee Form' : 'Add New Employee'}
      </button>

      {/* Conditionally render the EmployeeForm */}
      {isFormVisible && <EmployeeForm />}
      {adminProfile && <AdminProfile profile={adminProfile} />}
      {workspaceData && <WorkspaceData data={workspaceData} />}
      <Link to="/employees">Go to Employee Management</Link>
    </div>
  );
};

export default AdminDashboard;
