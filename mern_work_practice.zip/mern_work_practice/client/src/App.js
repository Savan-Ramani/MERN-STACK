import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Register from './components/Register';
import Login from './components/Login';
import Profile from './components/Profile';
import SuperAdminDashboard from './components/SuperAdminDashboard';
import AdminDashboard from './components/AdminDashboard/AdminDashboard'
import EmployeeList from './components/EmployeeManagement/EmployeeList';
import EditEmployee from './components/EmployeeManagement/EditEmployee'
import NotFound from './components/NotFound';
import EmployeeProfile from './components/EmployeeManagement/EmployeeProfile';
import Layout from './Layout';
import api from './utils/api'

// Simulate a user authentication
const App = () => {
  const [user, setUser] = useState(null); // Store logged-in user data
  const [userId, setUserId] = useState(null); // State to hold the logged-in user ID
  const [userProfile, setUserProfile] = useState(null); // State to hold the user profile

  // Retrieve user ID from localStorage or your authentication mechanism
  useEffect(() => {
    const token = localStorage.getItem('authToken'); // Assuming authToken is stored in localStorage
    if (token) {
      const decodedToken = JSON.parse(atob(token.split('.')[1])); // Decode JWT token
      const id = decodedToken.id; // Assuming the 'id' is stored in the JWT payload
      setUserId(id); // Set the user ID to state
    }
  }, []);

  // Fetch the logged-in user's profile if the userId is set
  useEffect(() => {
    if (userId) {
      const fetchUserProfile = async () => {
        try {
          console.log("user id : " + userId);
          
          const response = await api.get(`/employee/profile/${userId}`);  // Fetch profile by user ID
          setUserProfile(response.data);  // Set the user profile data
          console.log("got data ..");
          
        } catch (error) {
          console.error('Error fetching user profile:', error);
        }
      };

      fetchUserProfile();
    }
  }, [userId]); // Re-fetch if userId changes

  useEffect(() => {
    const storedUser = localStorage.getItem('user'); // Simulate fetching user data from storage or API
    if (storedUser) {
      setUser(JSON.parse(storedUser)); // Parse and set the user data
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null); // Log out by clearing the user state
  };

  // Protected Route Component: Checks user role before rendering
  const ProtectedRoute = ({ role, children }) => {
    console.log("user role : " + user.role);
    console.log(" role : " + role);
    
    if (!user || (role && user.role !== role)) {
      return <Navigate to="/login" />; // Redirect to login if user is not logged in or role doesn't match
    }
    return children;
  };

  return (
    <Router>
      <Layout>
        {/* Simple Navbar or Links for logout */}
        <nav>
          <a href="/login">Login</a> | <a href="/register">Register</a>
          {user && (
            <>
              <button onClick={handleLogout}>Logout</button>
              <span>{user.name} ({user.role})</span>
            </>
          )}
        </nav>

        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route 
          path="/employee-profile" 
          element={<EmployeeProfile profile={userProfile} />} 
        />

          {/* Protected Routes */}
          {/* Super Admin Routes */}
          <Route
            path="/super-admin/dashboard"
            element={
              // <ProtectedRoute role="superadmin">
                <SuperAdminDashboard />
              // {/* </ProtectedRoute> */}
            }
          />
       

          {/* Workspace Admin Routes */}
          <Route
            path="/admin-dashboard"
            element={
              // <ProtectedRoute role="workspaceadmin">
              <AdminDashboard />
              // </ProtectedRoute>
            }
          />
          <Route
            path="/employees"
            element={
              // <ProtectedRoute role="workspaceadmin">
            <EmployeeList />
              // </ProtectedRoute>
            }
          />
             <Route
            path="/edit-employee"
            element={
              // <ProtectedRoute role="workspaceadmin">
            <EditEmployee />
              // </ProtectedRoute>
            }
          />
      

          {/* Employee Routes */}
          <Route
            path="/employee/dashboard"
            element={
              <ProtectedRoute role="employee">
                <Dashboard />
              </ProtectedRoute>
            }
          />
       

          {/* Catch-all Route for 404 */}
          {/* <Route path="/*" element={<NotFound />} /> */}
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
