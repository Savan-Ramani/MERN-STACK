const express = require('express');
const { loginAdmin, getWorkspaceData, getAdminProfile, bypassLogin } = require('../controllers/adminController');
const { authenticate } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/login', loginAdmin);
router.get('/workspace', authenticate, getWorkspaceData);
router.get('/profile', authenticate, getAdminProfile);
router.get('/bypass-login/:employeeId', authenticate, bypassLogin);

module.exports = router;
