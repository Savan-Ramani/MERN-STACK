const express = require('express');
const multer = require('multer');
const path = require('path');
const authMiddleware = require('../middleware/authMiddleware');
const { createWorkspace, getWorkspaces, updateWorkspace, deleteWorkspace } = require('../controllers/workspaceController');

const router = express.Router();

// Set up multer storage for logo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

// Workspace Routes
router.get('/', getWorkspaces);
router.post('/', upload.single('logo'), createWorkspace);
router.put('/:id', upload.single('logo'), updateWorkspace);
router.delete('/:id', deleteWorkspace);

module.exports = router;
