const express = require('express');
const { addEmployee, getEmployees, exportEmployeesCSV,updateEmployee,deleteEmployee,getEmployeeProfile } = require('../controllers/employeeController');
const { authenticate } = require('../middleware/authMiddleware');  // Authentication middleware
const router = express.Router();

// POST route to add a new employee
router.post('/', addEmployee);

// GET route to fetch all employees
router.get('/', getEmployees);

// GET route to export employees data to CSV
router.get('/export', exportEmployeesCSV);

// Edit employee (PUT request)
router.put('/:id', updateEmployee);

// Delete employee (DELETE request)
router.delete('/:id', deleteEmployee);

router.get('/profile/:id', getEmployeeProfile);

module.exports = router;
