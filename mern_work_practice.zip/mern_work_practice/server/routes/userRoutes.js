const express = require('express');
const { getUsers, addUser, updateUser, deactivateUser } = require('../controllers/userController');
const { protect, roleCheck } = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/', protect, roleCheck(['superadmin', 'workspaceadmin']), getUsers);
router.post('/add', protect, roleCheck(['superadmin', 'workspaceadmin']), addUser);
router.put('/:userId', protect, roleCheck(['superadmin', 'workspaceadmin']), updateUser);
router.delete('/:userId', protect, roleCheck(['superadmin', 'workspaceadmin']), deactivateUser);

module.exports = router;
