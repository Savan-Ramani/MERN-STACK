// db.js
const mongoose = require('mongoose');

const connectDB = async () => {
  try {                   
    await mongoose.connect("mongodb+srv://savan93137:3l7NfEESiLZOWNAe@mernstack-db.6xjs2.mongodb.net/?retryWrites=true&w=majority&appName=mernstack-db", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected');
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1); // Exit process with failure
  }
};

module.exports = connectDB;
