const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['superadmin', 'workspaceadmin', 'employee'], default: 'employee' },
  company: { type: String },
  dob: { type: Date },
  department: { type: String },
  mobile: { type: String },
  profilePicture: { type: String },
  joiningDate: { type: Date },
  workspaceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Workspace' }
});

module.exports = mongoose.model('User', userSchema);
