const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String },
    address: { type: String },
    companyName: { type: String },
    companyAddress: { type: String },
    experience: { type: Number },
    department: { type: String },
    joiningDate: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    workspaceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Workspace' }
});

module.exports = mongoose.model('Employee', EmployeeSchema);
