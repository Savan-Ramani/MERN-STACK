const mongoose = require('mongoose');

const AdminSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    name: { type: String },
    workspaceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Workspace' }
});

module.exports = mongoose.model('Admin', AdminSchema);
