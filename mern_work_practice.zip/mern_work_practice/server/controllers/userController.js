const User = require('../models/User');

const getUsers = async (req, res) => {
  const users = await User.find({ workspaceId: req.user.workspaceId });
  res.json(users);
};

const addUser = async (req, res) => {
  const { name, email, password, department, mobile } = req.body;
  const newUser = new User({ name, email, password, department, mobile, workspaceId: req.user.workspaceId });
  await newUser.save();
  res.status(201).json({ message: 'User added' });
};

const updateUser = async (req, res) => {
  const { userId } = req.params;
  const { name, department, mobile } = req.body;
  const updatedUser = await User.findByIdAndUpdate(userId, { name, department, mobile }, { new: true });
  res.json(updatedUser);
};

const deactivateUser = async (req, res) => {
  const { userId } = req.params;
  await User.findByIdAndUpdate(userId, { active: false });
  res.json({ message: 'User deactivated' });
};

module.exports = { getUsers, addUser, updateUser, deactivateUser };
