const Employee = require('../models/Employee'); // Assuming you're using Mongoose to interact with MongoDB
const { createObjectCsvWriter } = require('csv-writer');

// Add a new employee
exports.addEmployee = async (req, res) => {
  try {
    const { name, email, phone, address, companyName, companyAddress, experience, department, status } = req.body;

    const newEmployee = new Employee({
      name,
      email,
      phone,
      address,
      companyName,
      companyAddress,
      experience,
      department,
      status
    });

    await newEmployee.save();
    res.status(201).json(newEmployee);  // Respond with the newly created employee
  } catch (error) {
    console.error('Error adding employee:', error);
    res.status(500).json({ message: 'Error adding employee' });
  }
};


// Controller to get all employees with pagination
exports.getEmployees = async (req, res) => {
  const { page = 1, limit = 10 } = req.query;  // Default page 1, limit 10

  try {
    // Calculate the skip value based on the page and limit
    const skip = (page - 1) * limit;

    // Fetch paginated employees
    const employees = await Employee.find()
      .skip(skip)
      .limit(Number(limit));

    // Get total number of employees for pagination
    const totalEmployees = await Employee.countDocuments();

    // Return paginated employees along with the total number of employees
    res.status(200).json({ employees, totalEmployees });
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ message: 'Error fetching employees' });
  }
};

// Export employees to CSV
exports.exportEmployeesCSV = async (req, res) => {
  try {
    const employees = await Employee.find();

    const csvWriter = createObjectCsvWriter({
      path: 'employees.csv',
      header: [
        { id: 'name', title: 'Name' },
        { id: 'email', title: 'Email' },
        { id: 'phone', title: 'Phone' },
        { id: 'address', title: 'Address' },
        { id: 'companyName', title: 'Company Name' },
        { id: 'companyAddress', title: 'Company Address' },
        { id: 'experience', title: 'Experience' },
        { id: 'department', title: 'Department' },
        { id: 'status', title: 'Status' },
      ],
    });

    // Write the employee data to the CSV file
    await csvWriter.writeRecords(employees);

    // Send the file as a download
    res.download('employees.csv');
  } catch (error) {
    console.error('Error exporting employees:', error);
    res.status(500).send('Error exporting data');
  }
};

// Controller to update an employee
exports.updateEmployee = async (req, res) => {
  const { id } = req.params;  // Employee ID to update
  const updateData = req.body;  // New data to update

  try {
    // Find and update employee
    const updatedEmployee = await Employee.findByIdAndUpdate(id, updateData, { new: true });

    if (!updatedEmployee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    res.status(200).json({ message: 'Employee updated successfully', employee: updatedEmployee });
  } catch (error) {
    console.error('Error updating employee:', error);
    res.status(500).json({ message: 'Error updating employee' });
  }
};

// Controller to delete an employee
exports.deleteEmployee = async (req, res) => {
  console.log("deleting...");
  
  const { id } = req.params;  // Employee ID to delete

  try {
    const deletedEmployee = await Employee.findByIdAndDelete(id);

    if (!deletedEmployee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    res.status(200).json({ message: 'Employee deleted successfully', employee: deletedEmployee });
  } catch (error) {
    console.error('Error deleting employee:', error);
    res.status(500).json({ message: 'Error deleting employee' });
  }
};

exports.getEmployeeProfile = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id); // Get employee by ID
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.json(employee);  // Send employee data as response
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
