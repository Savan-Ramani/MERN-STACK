const Admin = require('../models/Admin');
const Workspace = require('../models/Workspace');
const Employee = require('../models/Employee');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Admin Login
const loginAdmin = async (req, res) => {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).send('Admin not found');

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) return res.status(400).send('Invalid credentials');

    const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
};

// Get workspace data
const getWorkspaceData = async (req, res) => {
    const workspace = await Workspace.findOne({ admin: req.user.id }).populate('admin');
    if (!workspace) return res.status(400).send('Workspace not found');
    res.json(workspace);
};

// View admin profile
const getAdminProfile = async (req, res) => {
    const admin = await Admin.findById(req.user.id);
    res.json(admin);
};

// Bypass login (view employee profile)
const bypassLogin = async (req, res) => {
    const { employeeId } = req.params;
    const employee = await Employee.findById(employeeId);
    if (!employee) return res.status(400).send('Employee not found');
    res.json(employee);
};

module.exports = { loginAdmin, getWorkspaceData, getAdminProfile, bypassLogin };
