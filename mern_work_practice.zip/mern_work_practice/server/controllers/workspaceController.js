const Workspace = require('../models/Workspace');

// Create a new workspace
const createWorkspace = async (req, res) => {
  const { name, email, phone, password, address } = req.body;

  try {
    const existingWorkspace = await Workspace.findOne({ $or: [{ email }, { phone }] });
    if (existingWorkspace) {
      return res.status(409).json({ message: 'Workspace with the same name, email, or phone already exists' });
    }

    const newWorkspace = new Workspace({ name, email, phone, password, address, logo: req.file ? req.file.path : null });
    await newWorkspace.save();
    res.status(201).json(newWorkspace);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all workspaces
const getWorkspaces = async (req, res) => {
  try {
    const workspaces = await Workspace.find();
    res.status(200).json(workspaces);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Update a workspace
const updateWorkspace = async (req, res) => {
  const { name, email, phone, password, address } = req.body;
  try {
    const updatedWorkspace = await Workspace.findByIdAndUpdate(
      req.params.id,
      { name, email, phone, password, address, logo: req.file ? req.file.path : null },
      { new: true }
    );
    if (!updatedWorkspace) {
      return res.status(404).json({ message: 'Workspace not found' });
    }
    res.status(200).json(updatedWorkspace);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete a workspace
const deleteWorkspace = async (req, res) => {
  try {
    const workspace = await Workspace.findByIdAndDelete(req.params.id);
    if (!workspace) return res.status(404).json({ message: 'Workspace not found' });
    res.status(200).json({ message: 'Workspace deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createWorkspace, getWorkspaces, updateWorkspace, deleteWorkspace };
