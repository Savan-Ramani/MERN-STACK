// server.js
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const { protect } = require('./middleware/authMiddleware'); 
const employeeRoutes = require('./routes/employeeRoutes');
const workspaceRoutes = require('./routes/workspaceRoutes');
dotenv.config();


// Initialize Express app
const app = express();

// Connect to MongoDB
connectDB();

// Middlewares
app.use(cors());
app.use(cookieParser());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', protect, userRoutes);

app.use('/api/workspaces', workspaceRoutes);
 // Updated route
// Employee Routes
app.use('/api/employee',(req, res, next) => {
  console.log('employee');  // Simple debug log
  next();  // Call the next middleware/controller
}, employeeRoutes);


// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
